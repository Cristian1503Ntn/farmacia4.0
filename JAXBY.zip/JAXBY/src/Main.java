import conexion.conexion;
import modelo.crudxml;
import modelo.titular;
import operaciones.opeahorros;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.crypto.spec.PSource;
import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main  {

    public static void main (String[] args) throws JAXBException, IOException, SQLException {
      /*  crudxml cr = new crudxml();
        ArrayList<titular> list = new ArrayList<titular>();
        cr.insertar(list);

       conexion db = new conexion();
        db.connect_to_db("banco","root","Thefrankorios123");

*/


        opeahorros opea=new opeahorros();
        opea.probarconexion();

        //opea.insertar();
/*
        System.out.printf("Ingrese el numero de cuenta a buscar: ");
        Scanner rd=new Scanner(System.in);
        String a = rd.next();
        //opea.buscar(a);
*/
        /*
        System.out.printf("INGRESE EL NUMERO DE CUENTA A ELIMINAR CUENTA: ");
        Scanner ra=new Scanner(System.in);
        String f =ra.next();
        opea.Eliminar(f);

*/

        opea.listar();

    }






}