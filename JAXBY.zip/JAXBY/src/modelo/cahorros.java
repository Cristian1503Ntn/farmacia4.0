package modelo;

import java.util.Scanner;

public class cahorros extends cuentas {

float intereses;


    public cahorros() {
    }

    public cahorros(String numcuenta, modelo.titular titular, float valini, float intereses) {
        super(numcuenta, titular, valini);
        this.intereses = intereses;
    }

    public float getIntereses() {
        return intereses;
    }

    public void setIntereses(float intereses) {
        this.intereses = intereses;
    }


    @Override
    public String toString() {
        return super.toString()+"cahorros{" +
                "intereses=" + intereses +
                '}';
    }



    public void leer(){    // caso especial aqui heredo de la clase titular
        super.leer();              // hereda el metodo qye tiene mi clase padre
        Scanner rs = new Scanner(System.in);
        System.out.println("Ingrese el interes");
        setIntereses(rs.nextFloat());







    }












}
