package modelo;
//efecto pibote
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;

//para xml
@XmlRootElement(name="titulares")
public class titulares  {


private ArrayList<titular>Titular=null;

    public titulares() {
    }

    public titulares(ArrayList<titular> titular) {
        Titular = titular;
    }

    @XmlElement(name="titulares")

    public ArrayList<titular> getTitular() {
        return Titular;
    }

    public void setTitular(ArrayList<titular> titular) {
        Titular = titular;
    }


}
