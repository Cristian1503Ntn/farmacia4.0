package modelo;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import java.util.Scanner;
@XmlRootElement(name="titulares")
@XmlType(propOrder ={"dni","nombre"} )
public class titular {

    String nombre;
    String dni;

    public titular() {
    }

    public titular(String nombre, String dni) {
        this.nombre = nombre;
        this.dni = dni;
    }

    @XmlElement(name = "nombre")
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    @XmlElement(name = "dni")
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "titular{" +
                "nombre='" + nombre + '\'' +
                ", dni='" + dni + '\'' +
                '}';
    }

    //polimorfismo para cruds  metodos

    public void leer(){
        Scanner rs = new Scanner(System.in); // variable de leer
        System.out.println("Ingrese el nombre");
        setNombre(rs.next());
        System.out.println("Ingrese el dni");
        setDni(rs.next());  // para lleer

    }


}
