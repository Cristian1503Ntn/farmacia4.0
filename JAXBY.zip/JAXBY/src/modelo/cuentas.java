package modelo;

import java.util.Scanner;

public abstract class cuentas {
    //clase abtracta por vamos a heredar para ser el papa
       String numcuenta;
       titular titular = new titular(); // composicion

    float valini;


    public cuentas() {
    }

    public cuentas(String numcuenta, modelo.titular titular, float valini) {
        this.numcuenta = numcuenta;
        this.titular = titular;
        this.valini = valini;
    }

    public String getNumcuenta() {
        return numcuenta;
    }

    public void setNumcuenta(String numcuenta) {
        this.numcuenta = numcuenta;
    }

    public modelo.titular getTitular() {
        return titular;
    }

    public void setTitular(modelo.titular titular) {
        this.titular = titular;
    }

    public float getValini() {
        return valini;
    }

    public void setValini(float valini) {
        this.valini = valini;
    }

    @Override
    public String toString() {
        return "cuentas{" +
                "numcuenta='" + numcuenta + '\'' +
                ", titular=" + titular +
                ", valini=" + valini +
                '}';
    }


    public void leer(){

        Scanner rs = new Scanner(System.in); // variable de leer

        System.out.println("Ingrese el numero de cuenta");

        setNumcuenta(rs.next());

         titular auxtitular = new titular();

         auxtitular.leer();
         setTitular(auxtitular);

        System.out.println("Ingrese el valor inicial");
        setValini(rs.nextFloat());






    }







}
