package modelo;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;

//clase pibote
@XmlRootElement(name="Ahorros")
public class CAHORRO {

    private ArrayList<cahorros>ahorros=null;

    public CAHORRO() {
    }

    public CAHORRO(ArrayList<cahorros> ahorros) {
        this.ahorros = ahorros;
    }
    @XmlElement(name="Ahorros")

    public ArrayList<cahorros> getAhorros() {
        return ahorros;
    }

    public void setAhorros(ArrayList<cahorros> ahorros) {
        this.ahorros = ahorros;
    }
}
