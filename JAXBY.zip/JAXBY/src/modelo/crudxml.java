package modelo;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

//creacion del crud xml
public class crudxml {


    public void insertar(ArrayList<titular>tit) throws JAXBException, IOException   // anadir exepciones
    {

// insertar crud
        JAXBContext conetexto = JAXBContext.newInstance(titulares.class);
        System.out.println("Ingrese los titulares");
        titular  t= new titular();
        titulares ts= new titulares();
        t.leer();
        tit.add(t);
        ts.setTitular(tit);
        Marshaller mars =conetexto.createMarshaller();
        mars.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
        mars.marshal(ts,new FileWriter("titulares.xml"));

    }



}
