package modelo;

import java.util.Scanner;

public class Ccorriente extends cuentas{

    float mantenimeinto;

    public Ccorriente() {
    }

    public Ccorriente(String numcuenta, modelo.titular titular, float valini, float mantenimeinto) {
        super(numcuenta, titular, valini);
        this.mantenimeinto = mantenimeinto;
    }

    public float getMantenimeinto() {
        return mantenimeinto;
    }

    public void setMantenimeinto(float mantenimeinto) {
        this.mantenimeinto = mantenimeinto;
    }

    @Override
    public String toString() {
        return super.toString()+"Ccorriente{" +
                "mantenimeinto=" + mantenimeinto +
                '}';
    }

    public void leer(){

        super.leer();

        Scanner rs = new Scanner(System.in);

        System.out.println("Ingrese el costo del mantenimiento");

        setMantenimeinto(rs.nextFloat());

    }



}
