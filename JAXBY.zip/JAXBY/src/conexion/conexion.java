package conexion;

import modelo.cahorros;
import modelo.titular;

import java.sql.*;
import java.util.ArrayList;

public class conexion {      // coneccion a la base de datos sql
    public Connection connect_to_db(String dbNombre, String usuario, String password){
        Connection con = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver"); //Implementacion de los drivers de mysql
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+dbNombre,usuario,password);
            if(con != null){
                System.out.println("Conexion Establecida");
            }else{
                System.out.println("Conexion Fallida");
            }
        }catch (Exception e){
            System.out.println(e);
        }
        return con;
    }

    //Funcion para insetar datos a la base de datos mysql
    public boolean insertar(cahorros cta  ) {
        boolean a = false;
        try (Connection cn = connect_to_db("banco", "root", "Thefrankorios123")) {
            String quetyIns = "INSERT INTO cahorro(NumeroCuenta,Cedula,Nombre,SaldoInicial,ValorInteres) VALUES(?,?,?,?,?)";
            PreparedStatement sentencia = cn.prepareStatement(quetyIns);
            sentencia.setString(1, cta.getNumcuenta());
            // es la composicios de titular
            titular t = cta.getTitular();
            sentencia.setString(2,t.getDni());
            sentencia.setString(3,t.getNombre());
            sentencia.setFloat(4,cta.getValini());
            sentencia.setFloat(5,cta.getIntereses());
            try {
                sentencia.execute();
                a=true;
            } catch (SQLException e) {
                System.out.printf("Error al insertar datos" + e);
            }
        }catch (SQLException e) {
                throw new RuntimeException(e);
            }
        return a;
    }


     //todo lo queseaesenconexion

    //busccar

    public cahorros buscar(String numc){

        cahorros cta=new cahorros();
        try (Connection cn = connect_to_db("banco", "root", "Thefrankorios123")) {
            String consulta="SELECT * FROM cahorro WHERE NumeroCuenta=?";
            PreparedStatement sentencia =cn.prepareStatement(consulta);
            sentencia.setString(1,numc);
            try {
                ResultSet rs=sentencia.executeQuery();
                while (rs.next()){
                    cta.setNumcuenta(rs.getString("NumeroCuenta")); //filas
                    titular ti = cta.getTitular();
                    ti.setDni(rs.getString("Cedula"));      // poner los mismos nombres que en las tablas
                    ti.setNombre(rs.getString("Nombre"));
                    cta.setValini(rs.getFloat("SaldoInicial"));
                }
            } catch (SQLException e) {
                System.out.printf("Error al insertar datos" + e);
            }
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return cta;

    }


    public boolean eliminarcta(String numc){

        boolean bc=false;
        try (Connection cn = connect_to_db("banco", "root", "Thefrankorios123")) {
            String consulta="DELETE FROM cahorro WHERE NumeroCuenta=?";
            PreparedStatement sentencia = cn.prepareStatement(consulta);
            sentencia.setString(1,numc);  //llega como parametro
            try {
                sentencia.execute();
                bc=true;
            } catch (SQLException e) {
                System.out.printf("Error al ELIMINAR datos" + e);
            }
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return bc;

    }

    public ArrayList<cahorros> listar() throws SQLException{

        Connection cn = connect_to_db("banco", "root", "Thefrankorios123");  // llamo a ala coneccion

        String consulta ="SELECT * FROM cahorro";
        PreparedStatement sentencia = cn.prepareStatement(consulta);
        ArrayList<cahorros> lista=new ArrayList<>();
        try {
            ResultSet rs=sentencia.executeQuery();
            while (rs.next()){
                cahorros cta =new cahorros();
                cta.setNumcuenta(rs.getString("NumeroCuenta"));
                titular ti = cta.getTitular();
                ti.setDni(rs.getString("Cedula"));
                ti.setNombre(rs.getString("Nombre"));
                cta.setValini(rs.getFloat("SaldoInicial"));
                cta.setIntereses(rs.getFloat("ValorInteres"));

                cta.setTitular(ti);
                lista.add(cta);
            }

        }catch (Exception e){
            System.out.println("ERROR NO HAY CUENTAS DE AHORROS");
        }
        return lista;
    }


    public void modificar(String modi){

        cahorros cta=new cahorros();
        







    }


}
