package operaciones;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

import conexion.conexion;
import modelo.cahorros;

public class opeahorros {


    //crud para cuenta de ahorros   no usar constructor vacio

    private final conexion oper;

    public opeahorros() {
        this.oper = new conexion();
    }

    // probar conexion
    public void probarconexion(){

       // probar la coneccion
        oper.connect_to_db("banco","root","Thefrankorios123");


    }

    public void insertar(){

        cahorros cta= new cahorros();  // llamo a al cuenta
        cta.leer();
        System.out.printf("Cuenta de ahorros Nueva");
        if(oper.insertar(cta)){

            System.out.printf("Ckeck");

        }
        else {

            System.out.println("Cross");

        }

    }

    // crud buscar
    public void buscar(String busc){

        System.out.printf("BUSCAR CTA AHORROS");

        System.out.printf("cuenta:"+oper.buscar(busc).toString());

    }


    public void Eliminar(String bc){

        System.out.printf("ELIMINAR CUENTA");

        if(oper.eliminarcta(bc)) {
            System.out.printf("LISTO");
        }

        else {

            System.out.printf("NO SE BORRO");

        }



    }

    public void listar() throws SQLException {

        ArrayList<cahorros> listahorro=oper.listar();
        System.out.printf("LISTA DE CUENTAS DE AHORROS : ");
        listahorro.forEach(cahorros -> {
            System.out.println("Ahorros: "+ cahorros.toString());
        });

    }






}
